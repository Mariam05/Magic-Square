public interface MagicSquareListener {
	public void handleMagicSquareEvent(MagicSquareEvent e);
	
	public void handleResetGame();
}
